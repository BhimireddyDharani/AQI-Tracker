import pandas as pd
from storage import read_raw_data, save_processed_data

def detect_spikes(df):
    threshold = 3  # AQI > 3 = unhealthy
    df['Alert'] = df['AQI'].apply(lambda x: "Yes" if x > threshold else "No")
    df['Spike'] = (df['AQI'] > df['AQI'].mean() + df['AQI'].std()).map({True: "Spike", False: "Normal"})
    return df

def process_data():
    df = read_raw_data()
    if df.empty:
        return df
    df = detect_spikes(df)
    save_processed_data(df)
    return df
