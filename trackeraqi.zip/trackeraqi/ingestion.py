import requests
import pandas as pd
from config import API_KEY, RAW_DATA_PATH

def get_coordinates(city):
    url = f"http://api.openweathermap.org/geo/1.0/direct?q={city}&limit=1&appid={API_KEY}"
    res = requests.get(url).json()
    if res:
        return res[0]['lat'], res[0]['lon']
    return None, None

def fetch_aqi_data(city):
    lat, lon = get_coordinates(city)
    if not lat:
        return None

    url = f"http://api.openweathermap.org/data/2.5/air_pollution?lat={lat}&lon={lon}&appid={API_KEY}"
    res = requests.get(url).json()
    if 'list' not in res:
        return None

    comp = res['list'][0]['components']
    aqi = res['list'][0]['main']['aqi']

    df = pd.DataFrame([{
        'City': city,
        'AQI': aqi,
        'PM2.5': comp['pm2_5'],
        'PM10': comp['pm10'],
        'CO': comp['co'],
        'NO2': comp['no2'],
        'O3': comp['o3'],
        'SO2': comp.get('so2', 0)
    }])
    return df

def ingest_cities(cities):
    all_data = []
    for city in cities:
        df = fetch_aqi_data(city)
        if df is not None:
            all_data.append(df)
    if all_data:
        final_df = pd.concat(all_data, ignore_index=True)
        final_df.to_csv(RAW_DATA_PATH, index=False)
        return final_df
    return pd.DataFrame()
