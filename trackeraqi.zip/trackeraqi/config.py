# config.py
API_KEY = "b2aac5c95c76aa0fe5f8519497d59d6d"  # Replace with your OpenWeatherMap API key
RAW_DATA_PATH = "data/raw_data.csv"
PROCESSED_DATA_PATH = "data/processed_data.csv"
