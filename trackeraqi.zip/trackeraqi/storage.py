import pandas as pd
from config import RAW_DATA_PATH, PROCESSED_DATA_PATH

def read_raw_data():
    return pd.read_csv(RAW_DATA_PATH)

def save_processed_data(df):
    df.to_csv(PROCESSED_DATA_PATH, index=False)
