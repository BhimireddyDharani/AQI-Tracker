import streamlit as st
import pandas as pd
import plotly.express as px
from ingestion import ingest_cities
from process_data import process_data

st.set_page_config(page_title="Real-Time AQI Monitoring", layout="wide")
st.title("🌍 Real-Time Air Quality Monitoring & Alerts")

# Step 1: Input cities
cities_input = st.text_input("Enter cities (comma-separated)", "Delhi, Hyderabad, London, Tokyo")

# Function to map AQI to colors
def aqi_color(aqi):
    if aqi == 1:
        return "green"      # Good
    elif aqi == 2:
        return "orange"     # Moderate
    else:
        return "red"        # Unhealthy / Bad

if st.button("Fetch & Process AQI Data"):
    cities = [c.strip() for c in cities_input.split(",")]

    # Step 2: Ingest Data
    st.info("📥 Fetching raw data...")
    ingest_cities(cities)

    # Step 3: Process Data
    st.info("⚙️ Processing data...")
    df = process_data()

    st.success("✅ Data fetched and processed successfully!")
    st.dataframe(df)

    # Add AQI color column
    df['AQI_Color'] = df['AQI'].apply(aqi_color)

    # Step 4: AQI Bar Graph with Quality Colors
    fig = px.bar(df, x='City', y='AQI', color='AQI_Color',
                 color_discrete_map={'green':'green','orange':'orange','red':'red'},
                 title="City-wise AQI Levels")
    st.plotly_chart(fig, use_container_width=True)

    # Step 5: Pollutant Trends
    pollutants = ['PM2.5', 'PM10', 'CO', 'NO2', 'O3', 'SO2']
    df_melt = df.melt(id_vars=['City'], value_vars=pollutants)
    fig2 = px.line(df_melt, x='City', y='value', color='variable', markers=True,
                   title="Pollutant Concentration Levels (µg/m³)")
    st.plotly_chart(fig2, use_container_width=True)

    # Step 6: Alerts
    alerts = df[df['Alert'] == "Yes"]
    if not alerts.empty:
        st.warning("⚠️ Pollution Spike Detected!")
        st.dataframe(alerts)

    # Step 7: Download
    st.download_button(label="📥 Download Processed CSV",
                       data=df.to_csv(index=False).encode('utf-8'),
                       file_name='processed_aqi_data.csv',
                       mime='text/csv')
